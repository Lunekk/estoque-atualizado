// js/script.js
$(document).ready(function() {
  // Validação e ação para o formulário de login
  $('#loginForm').on('submit', function(e) {
    e.preventDefault();
    const username = $('#username').val().trim();
    const password = $('#password').val().trim();
    
    if (username === '' || password === '') {
      alert('Preencha todos os campos!');
      return;
    }
    
    // Simula um login bem-sucedido e redireciona para o painel
    window.location.href = 'principal.html';
  });
  
  // Validação e ação para o formulário de cadastro
  $('#cadastroForm').on('submit', function(e) {
    e.preventDefault();
    const nome = $('#nome').val().trim();
    const email = $('#email').val().trim();
    const usuario = $('#usuario').val().trim();
    const senha = $('#senha').val().trim();
    const confirmarSenha = $('#confirmarSenha').val().trim();
    
    if (nome === '' || email === '' || usuario === '' || senha === '' || confirmarSenha === '') {
      alert('Preencha todos os campos!');
      return;
    }
    
    if (senha !== confirmarSenha) {
      alert('As senhas não conferem!');
      return;
    }
    
    // Simula um cadastro bem-sucedido
    alert('Cadastro realizado com sucesso!');
    window.location.href = 'index.html';
  });
});

// script.js
$(document).ready(function() {
  // Quando qualquer link do menu for clicado
  $('.menu-link').on('click', function(e) {
    e.preventDefault();
    
    // Remove a classe "active" de todos os links e adiciona no link clicado
    $('.menu-link').removeClass('active');
    $(this).addClass('active');
    
    // Identifica qual é a "página" alvo
    let paginaAlvo = $(this).data('target');
    
    // Oculta todas as "páginas"
    $('.conteudo-pagina').addClass('d-none');
    
    // Mostra apenas a div correspondente
    $('#' + paginaAlvo).removeClass('d-none');
  });
});



                                                              // AQUI É ONDE COMEÇA A PARTE DO CONTROLE DE PERFIS


// js/script.js
$(document).ready(function() {
  // Mock de usuários (futuramente virá do banco de dados ou API)
  let usuarios = [
    { nome: 'João Silva', email: 'joao@example.com', usuario: 'joaosilva' },
    { nome: 'Maria Souza', email: 'maria@example.com', usuario: 'mariasouza' },
    { nome: 'Carlos Santos', email: 'carlos@example.com', usuario: 'carlossantos' }
  ];

  // ---------------------------
  // 1. LÓGICA DE TROCA DE PÁGINAS
  // ---------------------------
  $('.menu-link').on('click', function(e) {
    e.preventDefault();

    // Remove "active" de todos e adiciona no clicado
    $('.menu-link').removeClass('active');
    $(this).addClass('active');

    // Identifica qual div deve ser exibida
    const target = $(this).data('target');

    // Esconde todas as divs com .conteudo-pagina
    $('.conteudo-pagina').addClass('d-none');

    // Mostra apenas a div alvo
    $('#' + target).removeClass('d-none');
  });

  // ---------------------------
  // 2. FUNÇÃO PARA RENDERIZAR TABELA DE USUÁRIOS
  // ---------------------------
  function renderUserTable() {
    const tbody = $('#userTable tbody');
    tbody.empty(); // limpa linhas anteriores

    usuarios.forEach((user, index) => {
      const row = `
        <tr>
          <td>${user.nome}</td>
          <td>${user.email}</td>
          <td>${user.usuario}</td>
          <td>
            <button class="btn btn-sm btn-info btn-edit" data-index="${index}">
              Editar
            </button>
          </td>
        </tr>
      `;
      tbody.append(row);
    });
  }

  // ---------------------------
  // 3. ABRIR MODAL DE EDIÇÃO AO CLICAR EM "EDITAR"
  // ---------------------------
  $(document).on('click', '.btn-edit', function() {
    const index = $(this).data('index');
    const user = usuarios[index];

    // Preenche o form do modal com os dados do usuário
    $('#editIndex').val(index);
    $('#editNome').val(user.nome);
    $('#editEmail').val(user.email);
    $('#editUsuario').val(user.usuario);

    // Abre o modal
    $('#editUserModal').modal('show');
  });

  // ---------------------------
  // 4. SALVAR ALTERAÇÕES DO USUÁRIO
  // ---------------------------
  $('#editUserForm').on('submit', function(e) {
    e.preventDefault();
    
    const index = $('#editIndex').val();
    // Atualiza o array com os novos valores
    usuarios[index].nome = $('#editNome').val();
    usuarios[index].email = $('#editEmail').val();
    usuarios[index].usuario = $('#editUsuario').val();

    // Fecha o modal
    $('#editUserModal').modal('hide');

    // Re-renderiza a tabela para refletir as mudanças
    renderUserTable();
  });

  // Renderiza a tabela de usuários assim que a página carrega
  renderUserTable();
});


                                                      //  AQUI É ONDE COMEÇA O SCRIPT DA PARTE DO CONTROLE DE ESTOQUE



$(document).ready(function() {
  // ======================
  // TROCA DE PÁGINAS
  // ======================
  $('.menu-link').on('click', function(e) {
    e.preventDefault();
    $('.menu-link').removeClass('active');
    $(this).addClass('active');

    const target = $(this).data('target');
    $('.conteudo-pagina').addClass('d-none');
    $('#' + target).removeClass('d-none');
  });

  // ======================
  // PERFIL DE USUÁRIOS (exemplo)
  // ======================
  let usuarios = [
    { nome: 'João Silva', email: 'joao@example.com', usuario: 'joaosilva' },
    { nome: 'Maria Souza', email: 'maria@example.com', usuario: 'mariasouza' }
  ];

  function renderUserTable() {
    const tbody = $('#userTable tbody');
    tbody.empty();
    usuarios.forEach((user, index) => {
      const row = `
        <tr>
          <td>${user.nome}</td>
          <td>${user.email}</td>
          <td>${user.usuario}</td>
          <td>
            <button class="btn btn-sm btn-info btn-edit" data-index="${index}">
              Editar
            </button>
          </td>
        </tr>
      `;
      tbody.append(row);
    });
  }

  // Abrir modal de edição
  $(document).on('click', '.btn-edit', function() {
    const index = $(this).data('index');
    const user = usuarios[index];
    $('#editIndex').val(index);
    $('#editNome').val(user.nome);
    $('#editEmail').val(user.email);
    $('#editUsuario').val(user.usuario);
    $('#editUserModal').modal('show');
  });

  // Salvar alterações do usuário
  $('#editUserForm').on('submit', function(e) {
    e.preventDefault();
    const index = $('#editIndex').val();
    usuarios[index].nome = $('#editNome').val();
    usuarios[index].email = $('#editEmail').val();
    usuarios[index].usuario = $('#editUsuario').val();
    $('#editUserModal').modal('hide');
    renderUserTable();
  });

  // Inicializa tabela de usuários
  renderUserTable();
  
  // ======================
  // CONTROLE DE PREÇO (exemplo)
  // ======================
  
  // ======================
  // CONTROLE DE ESTOQUE (exemplo)
  // ======================
  let products = [
    { nome: 'Termômetro Digital', categoria: 'Equipamentos Médicos', quantidade: 20, preco: 100.00 },
    { nome: 'Máscara Cirúrgica', categoria: 'EPI', quantidade: 200, preco: 2.50 },
    { nome: 'Luvas Descartáveis', categoria: 'EPI', quantidade: 150, preco: 0.50 },
    { nome: 'Balança de Precisão', categoria: 'Equipamentos Médicos', quantidade: 10, preco: 500.00 },
    { nome: 'Soro Fisiológico 500ml', categoria: 'Medicamentos', quantidade: 50, preco: 5.00 }
  ];

  function renderProductTable() {
    const tbody = $('#productTable tbody');
    tbody.empty();
    products.forEach((prod, index) => {
      const precoFormatado = `R$ ${prod.preco.toFixed(2)}`;
      const row = `
        <tr>
          <td>${prod.nome}</td>
          <td>${prod.categoria}</td>
          <td>${prod.quantidade}</td>
          <td>${precoFormatado}</td>
          <td>
            <button class="btn btn-sm btn-info btn-edit-product" data-index="${index}">Editar</button>
            <button class="btn btn-sm btn-danger btn-delete-product" data-index="${index}">Excluir</button>
          </td>
        </tr>
      `;
      tbody.append(row);
    });
  }

  // Abrir modal de adicionar produto
  $('#btnAddProduct').on('click', function() {
    $('#addProductForm')[0].reset();
    $('#addProductModal').modal('show');
  });

  // Adicionar novo produto
  $('#addProductForm').on('submit', function(e) {
    e.preventDefault();
    const nome = $('#addNome').val().trim();
    const categoria = $('#addCategoria').val().trim();
    const quantidade = parseInt($('#addQuantidade').val(), 10);
    const preco = parseFloat($('#addPreco').val());
    if (!nome || !categoria || isNaN(quantidade) || isNaN(preco)) {
      alert('Preencha todos os campos corretamente!');
      return;
    }
    products.push({ nome, categoria, quantidade, preco });
    $('#addProductModal').modal('hide');
    renderProductTable();
  });

  // Abrir modal de edição de produto
  $(document).on('click', '.btn-edit-product', function() {
    const index = $(this).data('index');
    const prod = products[index];
    $('#editIndex').val(index);
    $('#editNome').val(prod.nome);
    $('#editCategoria').val(prod.categoria);
    $('#editQuantidade').val(prod.quantidade);
    $('#editPreco').val(prod.preco);
    $('#editProductModal').modal('show');
  });

  // Salvar alterações do produto
  $('#editProductForm').on('submit', function(e) {
    e.preventDefault();
    const index = parseInt($('#editIndex').val(), 10);
    products[index].nome = $('#editNome').val().trim();
    products[index].categoria = $('#editCategoria').val().trim();
    products[index].quantidade = parseInt($('#editQuantidade').val(), 10);
    products[index].preco = parseFloat($('#editPreco').val());
    $('#editProductModal').modal('hide');
    renderProductTable();
  });

  // Excluir produto
  $(document).on('click', '.btn-delete-product', function() {
    const index = $(this).data('index');
    if (confirm('Deseja realmente excluir este produto?')) {
      products.splice(index, 1);
      renderProductTable();
    }
  });

  // Inicializa tabela de produtos
  renderProductTable();
});












//  PARTE DO RELATÓRIO

function carregarRelatorio() {
  let produtos = JSON.parse(localStorage.getItem("produtos")) || [];
  let tabelaBody = document.getElementById("relatorioTableBody");
  let totalGeral = 0;
  
  tabelaBody.innerHTML = ""; // Limpa a tabela antes de preencher

  produtos.forEach(produto => {
      let valorTotal = produto.quantidade * produto.preco;
      totalGeral += valorTotal;

      let linha = `<tr>
          <td>${produto.nome}</td>
          <td>${produto.categoria}</td>
          <td>${produto.quantidade}</td>
          <td>R$ ${produto.preco.toFixed(2)}</td>
          <td>R$ ${valorTotal.toFixed(2)}</td>
      </tr>`;
      
      tabelaBody.innerHTML += linha;
  });

  document.getElementById("totalGeral").innerHTML = `<strong>R$ ${totalGeral.toFixed(2)}</strong>`;
}

// Chamando a função ao carregar a página de relatório
document.addEventListener("DOMContentLoaded", carregarRelatorio);
