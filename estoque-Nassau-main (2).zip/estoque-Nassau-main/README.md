# Controle de Estoque

Este é um sistema de controle de estoque desenvolvido com **HTML**, **CSS**, **JavaScript**, **jQuery** e **Bootstrap**. O projeto está organizado de forma modular para facilitar a manutenção e futuras integrações com back-end e banco de dados.

## Estrutura de Pastas

